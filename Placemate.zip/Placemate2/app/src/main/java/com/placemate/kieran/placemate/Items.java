package com.placemate.kieran.placemate;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;

public class Items extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);
    }

    int logic =3;
    public View getView(int position, View convertView, ViewGroup parent) {
        Button btn;
        LinearLayout layout;
        if (convertView == null) {

            //convertView = inflate the layout and initialize convertview

            if(position % logic==0)
                converView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT,
                    LinearLayout.LayoutParams.FILL_PARENT,
                    (float) 0.3));


            btn = new Button(context);
            btn.setGravity(Gravity.RIGHT);
            btn.setPadding(5, 5, 5, 5);


            layout = new LinearLayout(context);
            layout.setOrientation(0);
            layout.setPadding(5, 5, 5, 10);

            btn.setText(names[position]);

            layout.addView(btn);
        }
        else {
            layout = (LinearLayout) convertView;
            btn = (Button) layout.getChildAt(0);
            btn.setText(names[position]);

        }

        return layout;
    }
}

