package com.placemate.kieran.placemate;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;



public class Order extends Activity {

    private ListView lv;


    public void onCreate(Bundle saveInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        setContentView(R.layout.itemslist);

        lv = (ListView) findViewById(R.id.OrderListView);

        List<String> your_array_list = new ArrayList<String>();
        your_array_list.add("Garlic Bread £2.00");
        your_array_list.add("Chicken Burger £6.00");
        your_array_list.add("Chocolate Cake £4.00");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
                this,
                your_array_list );

        lv.setAdapter(arrayAdapter);
    }
}